import"./react-vendor-CmbxgZie.js";
